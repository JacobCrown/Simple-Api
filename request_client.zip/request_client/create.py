import requests
import pprint

endpoint = 'http://jacobcrown.pythonanywhere.com/api/create/'

data = {
    'imie': 'Maciej',
    'nazwisko': 'Wilhelm',
    'indeks': 423411,
    'pesel': '09237226417',
}

get_response = requests.post(endpoint, json=data)

pprint.pprint(get_response.json())

